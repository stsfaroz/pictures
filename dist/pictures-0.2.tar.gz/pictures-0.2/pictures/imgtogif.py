import os
from PIL import Image
import re
import glob
from IPython.display import Image as show_gif


class ImageFormat(Exception):
    def __init__(self, message, errors):
        super().__init__(message)
        self.errors = errors
class PathError(Exception):
    def __init__(self, message, errors):
        super().__init__(message)
        self.errors = errors
        


def convert(path="./",file_name="imgtogif.gif",to="./",img_format="all",duration=400,loop=0,number_sort="n",string_sort="n", gif_width=510,gif_height=310 ):
    
    """
    convert (path="./",file_name="imgtogif.gif",to="./",
    img_format="all",duration=400,loop=0,
    number_sort="n",string_sort="n",
    gif_width=510,gif_height=310 )

    Parameters:

    path:
    Path to the source of the image files
    file_name:
    File name for the gif to be saved 
    to:
    Destination of the gif file
    img_format:
    In which format of images are need to be converted to gif
    Formats are : png , jpg , jpeg or all
    duration:
    Duration of the gif
    loop:
    0 for gif to play again and again
    1 for play 1 time
    number_sort:
    [Sorting image files numerically]
    Example:
    images=[2.png,34.png,1.png]
    if number sort is yes means:
    this will be sorted as [1.png,2.png,34.png]
    and gif will be created
    string_sort:
    [sorting image files alphabetically]
    Example:
    images=[c.png,b.png,a.png]
    if string sort is yes means:
    this will be sorted as [a.png,b.png,c.png]
    and gif will be created
    gif_width:
    width of the gif
    gif_height:
    Height of the gif

    """
    imgfiles = []

    try:
        if os.path.exists(path):
            pass
        else:
            raise PathError("Source Path does not Exist","PathError")
        if os.path.exists(to):
            pass
        else:
            raise PathError("Destination Path does not Exist","PathError")



        if path[-1]=="/":
            pass
        else:
            path=path+"/"    


        if img_format=="png":
            for file in glob.glob(path +"/" +"*.png"):
                imgfiles.append(file)
        elif img_format=="jpg":
            for file in glob.glob(path+"/" +"*.jpg"):
                imgfiles.append(file)
        elif img_format=="jpeg":
            for file in glob.glob(path +"*.jpeg"):
                imgfiles.append(file)
        elif img_format=="all" or img_format=="All":
            for file in glob.glob(path +"/" +"*.png"):
                imgfiles.append(file)
            for file in glob.glob(path+"/" +"*.jpg"):
                imgfiles.append(file)
            for file in glob.glob(path +"*.jpeg"):
                imgfiles.append(file)
        else:
            raise ImageFormat("Image format is not correct","ImageError")


        filelist=[]    
        files=[]
        for i in imgfiles:
                files.append(i.replace(path,""))

        if number_sort=="y" or number_sort=="yes":
            files= sorted(files,key=lambda x: int(os.path.splitext(x)[0]))
        elif string_sort=="y" or string_sort=="yes" :
            files.sort()
        else:
            pass


        new_im=[]
        for file in files:
            new_frame = Image.open(path+file)
            img = new_frame.resize((gif_width, gif_height), Image.ANTIALIAS)
            new_im.append(img)

        if to[-1]=="/":
            pass
        else:
            to=to+"/"   

        new_im[0].save(to+file_name, format='GIF',append_images=new_im[:],save_all=True,duration=600, loop=0)
    finally:
        pass
